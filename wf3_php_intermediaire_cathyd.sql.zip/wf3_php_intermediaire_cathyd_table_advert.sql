
-- --------------------------------------------------------

--
-- Structure de la table `advert`
--

CREATE TABLE `advert` (
  `id` int(5) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `postal_code` int(5) NOT NULL,
  `city` varchar(30) NOT NULL,
  `type` enum('vente','location') NOT NULL,
  `price` varchar(10) NOT NULL,
  `reservation_message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `advert`
--

INSERT INTO `advert` (`id`, `title`, `description`, `postal_code`, `city`, `type`, `price`, `reservation_message`) VALUES
(3, 'Maison contemporaine', 'Jolie maison contemporaine.\r\nSituée sur lannion servel a proximité des écoles .\r\nAxe Trebeurden Pleumeur Bodou .\r\nElle se compose d’une entrée lumineuse.placard buanderie ,garage ,un séjour cuisine équipée. Possibilité d’extension jardin construction..\r\nA l’étage 2 chambres(bureau) salle de bain et Wc.\r\nMaison très fonctionnelle.\r\nDPE B', 22300, 'Lannion', 'vente', '280 000 €', 'Réserver'),
(4, 'Maison chavagne', 'Charmante maison de 2021 situé sur la commune de Chavagné (la crèche) à 5 minutes de Géant et la zone commerciale et 3 minutes de l’entrée de l’autoroute.\r\nLa maison est située dans un petit et silencieux lotissement de 6 maisons. Une école primaire se trouve à 500 mètres et toutes les commodités sont disponibles à 5 minutes.\r\nLa maison comprend un grand salon/séjour de 46m² ouvert sur la cuisine.\r\n3 chambres dont une suite parentale avec son coin dressing et salle d’eau.\r\nUn bureau idéal pour faire du télétravail ou possibilité de l’aménager en une 4ème chambre.\r\nSalle de bain avec baignoire et une grande douche\r\nUn cellier ainsi qu’un garage de 20m² vienne compléter les prestations.\r\nSystème de chauffage réversible afin de vous permettre de rafraîchir la maison les jours de fortes chaleurs.\r\nTerrain atypique de 1300 m² . Reste une clôture à faire.', 79260, 'La Crèche', 'vente', '290 000 €', ''),
(5, 'Appartement T3', 'Appartement avec entrée,cuisine,2 chambres, salle de bain, wc, grand séjour, grand garage la cuisine et le séjour donnent sur une terrasse de 15 m² .situé à 11 km de Capdenac 9km de Montbazens 11km de Decazeville 35km de Villefranche de Rouergue 45km de Rodez', 12220, 'Les Albres', 'location', '460 €', ''),
(6, 'Appartement DUPLEX', 'Appartement duplex de 54 m2, dans petite copropriété de deux étages, comprenant une cuisine-séjour et toilettes au premier étage et deux chambres dont une avec mezzanine et salle de bain avec douche, wc au deuxième étage. Double vitrage, interphone, chauffage par le sol pour le 1er étage et caloporteurs pour les chambres. Libre de suite. Loyer : 398 € et 10 € charges', 11330, 'Albières', 'location', '408 €', ''),
(7, 'Appartement 3 pièces 66 m', 'Appartement 3 pièces de 65m², au 1er étage, à vendre aux Andelys. Il vous offre une entrée, un séjour, une cuisine aménagée et équipée, deux chambres dont une suite parentale, 2 salles de bains avec WC et un petit grenier aménagé. Chauffage individuel. En plein cœur des Andelys, dans une petite copropriété avec faibles charges (5 lots), à proximité des commerces. A 50mn de Mantes-la-Jolie, 20mn de Vernon et proche de la gare routière.', 27700, 'Les Andelys', 'vente', '137 800 €', ''),
(8, 'Maison toulois', 'Maison sur la commune de Crézilles (54113):\r\n\r\nSpacieuse parfaite pour accueillir une famille avec 3 chambres.\r\nChauffage avec 2 poêles à granulés avec une climatisation air-air.\r\nGrande véranda donnant sur le magnifique jardin en 2 niveaux : le premier avec un vrai espace de détente avec ses 2 terrasses et son spa enterré, le deuxième avec trois arbres fruitiers et un espace pour jardiner le tout avec une vue magnifique sur la nature.\r\nA visiter sans tarder.', 54200, 'Toul', 'vente', '330 000 €', '');
